"""Helpers for tests (of this package and of the services that use it)."""

from __future__ import annotations

from collections.abc import Iterator, Mapping, Sequence
from contextlib import contextmanager
from typing import Any

from . import _runtime
from .exporters import TraceExporter


class MemorySink(_runtime.Sink):
    """Collects log records as dicts."""

    def __init__(self) -> None:
        self.records: list[dict[str, Any]] = []

    def emit(self, record: dict[str, Any], line: str) -> None:
        self.records.append(record)

    def find(self, message: str) -> list[dict[str, Any]]:
        return [r for r in self.records if r["message"] == message]


class MemoryExporter(TraceExporter):
    """Collects exported span records."""

    def __init__(self) -> None:
        self.spans: list[Mapping[str, Any]] = []

    def export(self, spans: Sequence[Mapping[str, Any]]) -> None:
        self.spans.extend(spans)


@contextmanager
def capture(
    service_name: str = "test-service",
    *,
    level: str = "DEBUG",
    exporter: TraceExporter | None = None,
    sink: MemorySink | None = None,
    **config_overrides: Any,
) -> Iterator[MemorySink]:
    """Temporarily replace the runtime; yields the sink holding every record."""
    previous = _runtime._runtime
    sink = sink or MemorySink()
    config = _runtime.LoggingConfig(
        service_name=service_name, level=_runtime.parse_level(level), **config_overrides
    )
    runtime = _runtime.Runtime(config, sink=sink, exporter=exporter)
    _runtime._runtime = runtime
    try:
        yield sink
    finally:
        if runtime.processor is not None:
            runtime.processor.flush()
        runtime.shutdown()
        _runtime._runtime = previous
