"""Outgoing-call propagation for httpx clients (sync and async).

Usage::

    client = httpx.AsyncClient(event_hooks=async_event_hooks())

Each request gets a ``client`` span (child of the current span) and carries ``traceparent`` pointing
at that span, so the callee's server span becomes its child. Limitation: httpx does not call the
response hook when the request itself fails (connection error/timeout); such attempts produce the
propagated header but no client span.
"""

from __future__ import annotations

from typing import Any

from . import tracing

_SPAN_KEY = "shared_logging_span"


def _on_request(request: Any) -> None:
    parent = tracing.current_span()
    if parent is None:
        return
    client_span = tracing.start_detached_span(
        f"{request.method} {request.url.host}",
        kind="client",
        attributes={
            "http.method": request.method,
            "http.path": request.url.path,
            "peer.service": request.url.host,
            "component": "http.client",
        },
    )
    request.extensions[_SPAN_KEY] = client_span
    request.headers["traceparent"] = client_span.context.to_traceparent()
    request.headers["x-correlation-id"] = (
        client_span.context.correlation_id or client_span.context.trace_id
    )


def _on_response(response: Any) -> None:
    client_span = response.request.extensions.get(_SPAN_KEY)
    if client_span is None:
        return
    client_span.set_attribute("http.status_code", response.status_code)
    if response.status_code >= 500:
        client_span.set_status(tracing.STATUS_ERROR, f"HTTP {response.status_code}")
    client_span.end()


async def _async_on_request(request: Any) -> None:
    _on_request(request)


async def _async_on_response(response: Any) -> None:
    _on_response(response)


def event_hooks() -> dict[str, list[Any]]:
    """Hooks for ``httpx.Client``."""
    return {"request": [_on_request], "response": [_on_response]}


def async_event_hooks() -> dict[str, list[Any]]:
    """Hooks for ``httpx.AsyncClient``."""
    return {"request": [_async_on_request], "response": [_async_on_response]}
