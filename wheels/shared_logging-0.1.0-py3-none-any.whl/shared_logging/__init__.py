"""Shared structured logging and distributed tracing for every OBLIVION microservice.

Typical use::

    from shared_logging import get_logger

    logger = get_logger(__name__)
    logger.info("Processing order", order_id=order_id)

Once per process (entrypoint only)::

    import shared_logging
    shared_logging.init_logging("orders")

See ``docs/logging.md``.
"""

from __future__ import annotations

import dataclasses

from . import _runtime
from ._runtime import ExportConfig, LoggingConfig
from .asgi import TracingMiddleware
from .exporters import (
    AttributePolicy,
    HttpTraceExporter,
    HttpTransport,
    NullTraceExporter,
    TraceExporter,
    TraceExportError,
)
from .httpx_support import async_event_hooks, event_hooks
from .logger import Logger, get_logger
from .stdlib_bridge import install_stdlib_bridge
from .tracing import (
    Span,
    TraceContext,
    bind,
    continue_from_message,
    continue_trace,
    current_context,
    current_span,
    current_trace_id,
    extract_context,
    inject_headers,
    inject_message_metadata,
    span,
)

__all__ = [
    "AttributePolicy",
    "ExportConfig",
    "HttpTraceExporter",
    "HttpTransport",
    "Logger",
    "LoggingConfig",
    "NullTraceExporter",
    "Span",
    "TraceContext",
    "TraceExportError",
    "TraceExporter",
    "TracingMiddleware",
    "async_event_hooks",
    "bind",
    "continue_from_message",
    "continue_trace",
    "current_context",
    "current_span",
    "current_trace_id",
    "event_hooks",
    "extract_context",
    "get_logger",
    "init_logging",
    "inject_headers",
    "inject_message_metadata",
    "install_stdlib_bridge",
    "shutdown",
    "span",
]


def init_logging(
    service_name: str | None = None,
    *,
    config: LoggingConfig | None = None,
    environment: str | None = None,
    exporter: TraceExporter | None = None,
    capture_stdlib: bool = True,
) -> LoggingConfig:
    """Configure logging for this process. Call once, from the service entrypoint.

    ``service_name`` is the default identity; the ``SERVICE_NAME`` environment variable wins.
    Everything else comes from ``LOG_LEVEL``, ``LOG_FORMAT``, ``LOG_OUTPUT``, ``ENVIRONMENT`` and
    ``TRACE_EXPORT_*`` (see ``docs/logging.md``). ``environment`` overrides the detected one when
    the service resolves it by other means. ``exporter`` lets an entrypoint inject a custom
    :class:`TraceExporter`; normally it is built from configuration.
    """
    resolved = config or LoggingConfig.from_env(service_name)
    if environment:
        resolved = dataclasses.replace(resolved, environment=environment.strip().lower())
    runtime = _runtime.install_runtime(_runtime.Runtime(resolved, exporter=exporter))
    if capture_stdlib:
        install_stdlib_bridge()
    return runtime.config


def shutdown() -> None:
    """Flush queued trace exports (also runs automatically at interpreter exit)."""
    _runtime.shutdown()
