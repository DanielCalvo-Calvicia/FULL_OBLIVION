"""Optional trace export.

``TraceExporter`` is the only thing the tracing core depends on. ``HttpTraceExporter`` is one
implementation; it talks HTTP through the ``HttpTransport`` abstraction so the client library can
be swapped without touching anything else. Export is off unless ``TRACE_EXPORT_ENABLED=true``.

Safety rules that hold for every exporter in this module:

* exporting happens on a background thread, never on the caller's thread;
* a failing exporter never raises into application code;
* failures are reported with :func:`diagnostic` (a plain write to stderr), never through the
  shared ``Logger`` - so a broken exporter cannot produce spans/logs that feed the exporter again;
* only allow-listed span attributes leave the process, and secrets are masked even then.
"""

from __future__ import annotations

import json
import queue
import sys
import threading
import time
import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from ._redaction import redact_value

SCHEMA_VERSION = 1

_last_diagnostic: dict[str, float] = {}
_DIAGNOSTIC_INTERVAL = 30.0


def diagnostic(message: str) -> None:
    """Report a problem in the logging/tracing machinery itself (rate limited, never raises)."""
    now = time.monotonic()
    if now - _last_diagnostic.get(message, -_DIAGNOSTIC_INTERVAL) < _DIAGNOSTIC_INTERVAL:
        return
    _last_diagnostic[message] = now
    try:
        print(f"[shared_logging] {message}", file=sys.stderr, flush=True)
    except Exception:  # noqa: BLE001 - stderr may be closed at interpreter shutdown
        pass


class TraceExportError(Exception):
    """Raised by an exporter when a batch could not be delivered."""


class TraceExporter(ABC):
    """Receives finished spans (plain dicts, see ``Span.to_record``) in batches."""

    @abstractmethod
    def export(self, spans: Sequence[Mapping[str, Any]]) -> None:
        """Deliver ``spans``; raise :class:`TraceExportError` on failure."""

    def shutdown(self) -> None:  # noqa: B027 - optional hook
        """Release resources."""


class NullTraceExporter(TraceExporter):
    """Default exporter: does nothing, and tells the runtime not to queue anything."""

    def export(self, spans: Sequence[Mapping[str, Any]]) -> None:
        return None


@dataclass(frozen=True)
class AttributePolicy:
    """Decides which span attributes may leave the process.

    Everything not in ``allowed`` (or ``extra_allowed``, or under an allowed prefix) is dropped.
    Values of allowed attributes are still masked when they look like secrets.
    """

    allowed: frozenset[str] = frozenset(
        {
            "component",
            "http.method",
            "http.route",
            "http.path",
            "http.status_code",
            "peer.service",
            "messaging.system",
            "messaging.destination",
            "error.type",
        }
    )
    extra_allowed: frozenset[str] = frozenset()
    max_value_length: int = 256

    def filter(
        self, attributes: Mapping[str, Any], also_allowed: frozenset[str] = frozenset()
    ) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in attributes.items():
            if key not in self.allowed | self.extra_allowed | also_allowed:
                continue
            value = redact_value(key, value)
            if not isinstance(value, (str, int, float, bool)) and value is not None:
                value = str(value)
            if isinstance(value, str) and len(value) > self.max_value_length:
                value = value[: self.max_value_length]
            result[key] = value
        return result

    def sanitize_event(self, event: Mapping[str, Any]) -> dict[str, Any]:
        clean: dict[str, Any] = {
            "name": str(event.get("name", "")),
            "timestamp": event.get("timestamp"),
        }
        attributes = event.get("attributes") or {}
        # Events never carry free text (exception messages can embed user data): name, level and
        # error type only.
        clean["attributes"] = self.filter(attributes, also_allowed=_EVENT_ATTRIBUTES)
        return clean


_EVENT_ATTRIBUTES = frozenset({"level", "error.type"})


class HttpTransport(ABC):
    """Minimal HTTP client abstraction used by :class:`HttpTraceExporter`."""

    @abstractmethod
    def post(self, url: str, body: bytes, headers: Mapping[str, str], timeout: float) -> int:
        """POST ``body`` and return the HTTP status code.

        Must raise ``OSError`` (or a subclass) for connection problems and timeouts.
        """


class UrllibTransport(HttpTransport):
    """Standard-library transport. Deliberately not instrumented for tracing."""

    def post(self, url: str, body: bytes, headers: Mapping[str, str], timeout: float) -> int:
        request = urllib.request.Request(url, data=body, headers=dict(headers), method="POST")
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310
                response.read()
                return int(response.status)
        except urllib.error.HTTPError as error:
            return int(error.code)
        except urllib.error.URLError as error:
            raise OSError(str(error.reason)) from error


@dataclass
class HttpTraceExporter(TraceExporter):
    """POSTs ``{"schema_version": 1, "service": ..., "spans": [...]}`` as JSON."""

    url: str
    timeout: float = 2.0
    headers: Mapping[str, str] = field(default_factory=dict)
    transport: HttpTransport = field(default_factory=UrllibTransport)
    policy: AttributePolicy = field(default_factory=AttributePolicy)
    service: str = ""
    environment: str = ""

    def build_payload(self, spans: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "service": self.service,
            "environment": self.environment,
            "spans": [self._sanitize(span) for span in spans],
        }

    def _sanitize(self, span: Mapping[str, Any]) -> dict[str, Any]:
        clean = {k: v for k, v in span.items() if k not in ("attributes", "events")}
        clean["attributes"] = self.policy.filter(span.get("attributes") or {})
        clean["events"] = [self.policy.sanitize_event(e) for e in span.get("events") or []]
        return clean

    def request_headers(self) -> dict[str, str]:
        merged = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "shared-logging-trace-exporter/1",
        }
        merged.update(self.headers)
        return merged

    def export(self, spans: Sequence[Mapping[str, Any]]) -> None:
        if not spans:
            return
        body = json.dumps(self.build_payload(spans), default=str).encode("utf-8")
        try:
            status = self.transport.post(self.url, body, self.request_headers(), self.timeout)
        except Exception as error:  # noqa: BLE001 - any transport failure is an export failure
            raise TraceExportError(f"trace export to {self.url} failed: {error}") from error
        if status >= 400:
            raise TraceExportError(f"trace storage answered HTTP {status}")


class SpanProcessor:
    """Bounded queue plus one daemon thread that batches spans and hands them to the exporter."""

    _FLUSH = object()
    _STOP = object()

    def __init__(
        self,
        exporter: TraceExporter,
        *,
        batch_size: int = 32,
        flush_interval: float = 1.0,
        queue_size: int = 2048,
    ) -> None:
        self._exporter = exporter
        self._batch_size = max(1, batch_size)
        self._flush_interval = max(0.01, flush_interval)
        self._queue: queue.Queue[Any] = queue.Queue(maxsize=queue_size)
        self._thread: threading.Thread | None = None
        self._start_lock = threading.Lock()
        self._closed = False

    def submit(self, span: Mapping[str, Any]) -> None:
        """Queue a span without ever blocking; drops (and reports) when the queue is full."""
        if self._closed:
            return
        self._ensure_thread()
        try:
            self._queue.put_nowait(span)
        except queue.Full:
            diagnostic("trace export queue is full; dropping spans")

    def flush(self, timeout: float = 5.0) -> bool:
        """Block until everything queued so far was handed to the exporter (tests/shutdown)."""
        if self._thread is None:
            return True
        done = threading.Event()
        try:
            self._queue.put((self._FLUSH, done), timeout=timeout)
        except queue.Full:
            return False
        return done.wait(timeout)

    def shutdown(self, timeout: float = 5.0) -> None:
        if self._closed:
            return
        self.flush(timeout)
        self._closed = True
        thread = self._thread
        if thread is not None:
            try:
                self._queue.put_nowait(self._STOP)
            except queue.Full:
                pass
            thread.join(timeout)
        try:
            self._exporter.shutdown()
        except Exception:  # noqa: BLE001
            diagnostic("trace exporter shutdown failed")

    def _ensure_thread(self) -> None:
        if self._thread is not None:
            return
        with self._start_lock:
            if self._thread is None:
                self._thread = threading.Thread(
                    target=self._run, name="shared-logging-trace-export", daemon=True
                )
                self._thread.start()

    def _run(self) -> None:
        batch: list[Mapping[str, Any]] = []
        deadline: float | None = None
        while True:
            timeout = (
                self._flush_interval if deadline is None else max(0.0, deadline - time.monotonic())
            )
            try:
                item = self._queue.get(timeout=timeout)
            except queue.Empty:
                item = None  # interval elapsed
            if item is self._STOP:
                self._send(batch)
                return
            if isinstance(item, tuple) and item and item[0] is self._FLUSH:
                self._send(batch)
                batch, deadline = [], None
                item[1].set()
                continue
            if item is not None:
                if not batch:
                    deadline = time.monotonic() + self._flush_interval
                batch.append(item)
            if batch and (item is None or len(batch) >= self._batch_size):
                self._send(batch)
                batch, deadline = [], None

    def _send(self, batch: Sequence[Mapping[str, Any]]) -> None:
        if not batch:
            return
        try:
            self._exporter.export(list(batch))
        except TraceExportError as error:
            diagnostic(str(error))
        except Exception as error:  # noqa: BLE001 - an exporter must never kill the worker
            diagnostic(f"trace exporter crashed: {type(error).__name__}: {error}")
