"""Structured logger. One line per event; trace context is added automatically."""

from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime, timezone
from typing import Any

from . import _runtime, tracing
from ._redaction import redact_text, redact_value
from ._runtime import LEVEL_NAMES, LoggingConfig, parse_level

_RESERVED = frozenset(
    {
        "timestamp",
        "level",
        "service",
        "environment",
        "logger",
        "trace_id",
        "span_id",
        "parent_span_id",
        "correlation_id",
        "message",
        "exception",
    }
)
_MAX_STACK_CHARS = 16000


def _json_default(value: Any) -> str:
    if isinstance(value, BaseException):
        return f"{type(value).__name__}: {value}"
    return str(value)


def _render_console(record: dict[str, Any]) -> str:
    head = (
        f"{record['timestamp']} {record['level']:<8} service={record['service']} "
        f"logger={record['logger']}"
    )
    if "trace_id" in record:
        head += f" trace_id={record['trace_id']} span_id={record['span_id']}"
    parts = [head, f"message={json.dumps(record['message'], default=_json_default)}"]
    skip = _RESERVED | {"exception"}
    for key, value in record.items():
        if key not in skip:
            parts.append(f"{key}={json.dumps(value, default=_json_default)}")
    line = " ".join(parts)
    exc = record.get("exception")
    if exc:
        line += f"\n{exc['type']}: {exc['message']}\n{exc['stacktrace']}".rstrip()
    return line


def _exception_info(exc_info: Any) -> dict[str, Any] | None:
    if exc_info is True:
        exc_info = sys.exc_info()
    elif isinstance(exc_info, BaseException):
        exc_info = (type(exc_info), exc_info, exc_info.__traceback__)
    if not exc_info or exc_info[0] is None:
        return None
    exc_type, exc, tb = exc_info
    stack = "".join(traceback.format_exception(exc_type, exc, tb))
    return {
        "type": exc_type.__name__,
        "message": redact_text(str(exc)),
        "stacktrace": redact_text(stack)[-_MAX_STACK_CHARS:],
    }


class Logger:
    """Created with :func:`get_logger`. Field values may be any JSON-able (or ``str``-able) data."""

    __slots__ = ("name", "_bound")

    def __init__(self, name: str, bound: dict[str, Any] | None = None) -> None:
        self.name = name
        self._bound = bound or {}

    def bind(self, **fields: Any) -> Logger:
        """Return a logger that adds ``fields`` to every line it writes."""
        return Logger(self.name, {**self._bound, **fields})

    def is_enabled_for(self, level: int | str) -> bool:
        return parse_level(level) >= _runtime.get_runtime().config.level

    def debug(self, message: str, /, **fields: Any) -> None:
        self.log("DEBUG", message, **fields)

    def info(self, message: str, /, **fields: Any) -> None:
        self.log("INFO", message, **fields)

    def warning(self, message: str, /, **fields: Any) -> None:
        self.log("WARNING", message, **fields)

    warn = warning

    def error(self, message: str, /, **fields: Any) -> None:
        self.log("ERROR", message, **fields)

    def critical(self, message: str, /, **fields: Any) -> None:
        self.log("CRITICAL", message, **fields)

    def exception(self, message: str, /, **fields: Any) -> None:
        """ERROR line with the active exception (type, message, stack trace). Call in ``except``."""
        fields.setdefault("exc_info", True)
        self.log("ERROR", message, **fields)

    def log(self, level: int | str, message: str, /, **fields: Any) -> None:
        levelno = parse_level(level)
        runtime = _runtime.get_runtime()
        config: LoggingConfig = runtime.config
        if levelno < config.level:
            return
        try:
            self._emit(runtime, levelno, message, fields)
        except Exception as error:  # noqa: BLE001 - logging must never break the caller
            from .exporters import diagnostic

            diagnostic(f"failed to write log record: {type(error).__name__}: {error}")

    def _emit(
        self, runtime: _runtime.Runtime, levelno: int, message: str, fields: dict[str, Any]
    ) -> None:
        config = runtime.config
        exc_info = fields.pop("exc_info", None)
        record: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            "level": LEVEL_NAMES.get(levelno, str(levelno)),
            "service": config.service_name,
            "environment": config.environment,
            "logger": self.name,
        }
        active = tracing.current_span()
        if active is not None:
            ctx = active.context
            record["trace_id"] = ctx.trace_id
            record["span_id"] = ctx.span_id
            if ctx.parent_span_id:
                record["parent_span_id"] = ctx.parent_span_id
            record["correlation_id"] = ctx.correlation_id or ctx.trace_id
        record["message"] = redact_text(str(message))
        extra = {**self._bound, **tracing.bound_fields(), **fields}
        for key, value in extra.items():
            name = f"field_{key}" if key in _RESERVED else key
            record[name] = redact_value(key, value)
        exception = _exception_info(exc_info)
        if exception:
            record["exception"] = exception
        if active is not None and levelno >= 30:
            event: dict[str, Any] = {"level": record["level"]}
            if exception:
                event["error.type"] = exception["type"]
            active.add_event("log", **event)
            if levelno >= 40 and exception:
                active.set_status(tracing.STATUS_ERROR, exception["type"])
        line = (
            _render_console(record)
            if config.format == "console"
            else json.dumps(record, default=_json_default, ensure_ascii=False)
        )
        runtime.sink.emit(record, line)


def get_logger(name: str | None = None) -> Logger:
    """Return a logger. Use ``get_logger(__name__)`` at module level."""
    return Logger(name or "app")
