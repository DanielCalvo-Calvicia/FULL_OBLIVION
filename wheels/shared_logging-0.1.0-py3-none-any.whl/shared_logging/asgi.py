"""Pure-ASGI middleware: continues (or starts) the trace for every incoming HTTP request.

Implemented as plain ASGI (not ``BaseHTTPMiddleware``) so the trace context stays active for the
whole response, including streaming bodies.
"""

from __future__ import annotations

import time
from typing import Any

from . import tracing
from .logger import get_logger

_logger = get_logger("shared_logging.http")
_QUIET_PATHS_DEFAULT: frozenset[str] = frozenset()


class TracingMiddleware:
    def __init__(self, app: Any, *, quiet_paths: frozenset[str] = _QUIET_PATHS_DEFAULT) -> None:
        self.app = app
        self.quiet_paths = quiet_paths

    async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope["headers"]}
        method = scope.get("method", "WS")
        path = scope.get("path", "")
        name = f"{method} {path}"
        started = time.perf_counter()
        status = {"code": 0}

        with tracing.continue_trace(
            headers,
            name,
            kind="server",
            attributes={"http.method": method, "http.path": path, "component": "http.server"},
        ) as active:
            trace_id = active.trace_id

            async def send_wrapper(message: dict[str, Any]) -> None:
                if message["type"] == "http.response.start":
                    status["code"] = message["status"]
                    message = {
                        **message,
                        "headers": [
                            *message.get("headers", []),
                            (b"x-trace-id", trace_id.encode()),
                        ],
                    }
                await send(message)

            quiet = path in self.quiet_paths
            if not quiet:
                _logger.info(
                    "Request received",
                    method=method,
                    path=path,
                    client=(scope.get("client") or ("", 0))[0],
                )
            try:
                await self.app(scope, receive, send_wrapper)
            except BaseException as exc:
                if not quiet and isinstance(exc, Exception):
                    _logger.exception("Request failed", method=method, path=path)
                raise
            finally:
                route = scope.get("route")
                route_path = getattr(route, "path", None)
                if route_path:
                    active.set_attribute("http.route", route_path)
                active.set_attribute("http.status_code", status["code"])
                if status["code"] >= 500:
                    active.set_status(tracing.STATUS_ERROR, f"HTTP {status['code']}")
            if not quiet:
                _logger.info(
                    "Request completed",
                    method=method,
                    path=path,
                    status_code=status["code"],
                    duration_ms=round((time.perf_counter() - started) * 1000, 2),
                )
