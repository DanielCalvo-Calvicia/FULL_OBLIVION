"""Routes third-party libraries that still use the standard ``logging`` module (uvicorn, httpx,
fastapi, ...) through the shared logger, so every line has the same structure and trace context.

Application code must not use ``logging`` directly; this bridge exists only for libraries.
"""

from __future__ import annotations

import logging

from .logger import get_logger

_SILENCED = ("uvicorn.access",)  # replaced by the middleware's "Request completed" event


class _BridgeHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        if record.name in _SILENCED:
            return
        try:
            get_logger(record.name).log(
                record.levelno,
                record.getMessage(),
                exc_info=record.exc_info if record.exc_info else None,
                source="stdlib-logging",
            )
        except Exception:  # noqa: BLE001
            self.handleError(record)


def install_stdlib_bridge(level: int = logging.NOTSET) -> None:
    root = logging.getLogger()
    root.handlers = [h for h in root.handlers if not isinstance(h, _BridgeHandler)]
    root.addHandler(_BridgeHandler())
    root.setLevel(level if level else logging.DEBUG)  # filtering is done by the shared logger
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access", "fastapi"):
        lib = logging.getLogger(name)
        lib.handlers = []
        lib.propagate = True
