"""Process-wide configuration and wiring. Nothing here is imported by application code."""

from __future__ import annotations

import atexit
import os
import sys
import threading
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from typing import Any, TextIO

from .exporters import (
    AttributePolicy,
    HttpTraceExporter,
    NullTraceExporter,
    SpanProcessor,
    TraceExporter,
    diagnostic,
)

LEVELS: dict[str, int] = {
    "TRACE": 5,
    "DEBUG": 10,
    "INFO": 20,
    "WARN": 30,
    "WARNING": 30,
    "ERROR": 40,
    "CRITICAL": 50,
    "FATAL": 50,
}
LEVEL_NAMES = {5: "TRACE", 10: "DEBUG", 20: "INFO", 30: "WARNING", 40: "ERROR", 50: "CRITICAL"}
_ENVIRONMENT_ALIASES = {"dev": "development", "stage": "staging", "prod": "production"}
_DEFAULT_SERVICE = "unknown-service"


def parse_level(value: str | int | None, default: int = 20) -> int:
    if value is None or value == "":
        return default
    if isinstance(value, int):
        return value
    text = value.strip().upper()
    if text.isdigit():
        return int(text)
    return LEVELS.get(text, default)


def _truthy(value: str | None) -> bool:
    return (value or "").strip().lower() in {"1", "true", "yes", "on"}


def _number(value: str | None, default: Any, cast: Callable[[str], Any] = float) -> Any:
    try:
        return cast(value) if value not in (None, "") else default
    except ValueError:
        return default


def _parse_headers(value: str | None) -> dict[str, str]:
    headers: dict[str, str] = {}
    for pair in (value or "").split(","):
        name, sep, val = pair.partition("=")
        if sep and name.strip():
            headers[name.strip()] = val.strip()
    return headers


@dataclass(frozen=True)
class ExportConfig:
    enabled: bool = False
    url: str = ""
    timeout: float = 2.0
    batch_size: int = 32
    flush_interval: float = 1.0
    queue_size: int = 2048
    headers: Mapping[str, str] = field(default_factory=dict)
    attribute_allowlist: tuple[str, ...] = ()


@dataclass(frozen=True)
class LoggingConfig:
    service_name: str = _DEFAULT_SERVICE
    environment: str = "development"
    level: int = 20
    format: str = "json"  # "json" or "console"
    output: str = "stdout"  # "stdout", "stderr" or a file path
    export: ExportConfig = field(default_factory=ExportConfig)

    @classmethod
    def from_env(
        cls,
        service_name: str | None = None,
        env: Mapping[str, str] | None = None,
    ) -> LoggingConfig:
        env = os.environ if env is None else env
        environment = (
            (env.get("ENVIRONMENT") or env.get("APP_ENV") or env.get("VSCODE_ENV") or "development")
            .strip()
            .lower()
        )
        fmt = (env.get("LOG_FORMAT") or "json").strip().lower()
        export = ExportConfig(
            enabled=_truthy(env.get("TRACE_EXPORT_ENABLED")),
            url=(env.get("TRACE_EXPORT_URL") or "").strip(),
            timeout=_number(env.get("TRACE_EXPORT_TIMEOUT"), 2.0),
            batch_size=max(1, _number(env.get("TRACE_EXPORT_BATCH_SIZE"), 32, int)),
            flush_interval=_number(env.get("TRACE_EXPORT_FLUSH_INTERVAL"), 1.0),
            queue_size=max(1, _number(env.get("TRACE_EXPORT_QUEUE_SIZE"), 2048, int)),
            headers=_parse_headers(env.get("TRACE_EXPORT_HEADERS")),
            attribute_allowlist=tuple(
                a.strip()
                for a in (env.get("TRACE_EXPORT_ATTRIBUTES") or "").split(",")
                if a.strip()
            ),
        )
        return cls(
            service_name=(env.get("SERVICE_NAME") or service_name or _DEFAULT_SERVICE).strip(),
            environment=_ENVIRONMENT_ALIASES.get(environment, environment),
            level=parse_level(env.get("LOG_LEVEL")),
            format=fmt if fmt in {"json", "console"} else "json",
            output=(env.get("LOG_OUTPUT") or "stdout").strip(),
            export=export,
        )


class Sink:
    """Destination for finished log records (a dict plus its rendered line)."""

    def emit(self, record: dict[str, Any], line: str) -> None:  # pragma: no cover - interface
        raise NotImplementedError


class StreamSink(Sink):
    def __init__(self, output: str) -> None:
        self._output = output
        self._lock = threading.Lock()
        self._file: TextIO | None = None
        if output not in {"stdout", "stderr"}:
            self._file = open(output, "a", encoding="utf-8")  # noqa: SIM115 - process lifetime

    def _stream(self) -> TextIO:
        if self._file is not None:
            return self._file
        return sys.stderr if self._output == "stderr" else sys.stdout

    def emit(self, record: dict[str, Any], line: str) -> None:
        with self._lock:
            try:
                stream = self._stream()
                stream.write(line + "\n")
                stream.flush()
            except (OSError, ValueError):
                pass  # logging must never break the caller (closed/broken pipe)


class Runtime:
    def __init__(
        self,
        config: LoggingConfig,
        sink: Sink | None = None,
        exporter: TraceExporter | None = None,
    ) -> None:
        self.config = config
        self.sink = sink or StreamSink(config.output)
        self.processor: SpanProcessor | None = None
        if exporter is None:
            exporter = build_exporter(config)
        if not isinstance(exporter, NullTraceExporter):
            self.processor = SpanProcessor(
                exporter,
                batch_size=config.export.batch_size,
                flush_interval=config.export.flush_interval,
                queue_size=config.export.queue_size,
            )
        self.exporter = exporter

    def record_span(self, span_record: dict[str, Any]) -> None:
        if self.processor is not None:
            self.processor.submit(span_record)

    def shutdown(self) -> None:
        if self.processor is not None:
            self.processor.shutdown()


def build_exporter(config: LoggingConfig) -> TraceExporter:
    export = config.export
    if not export.enabled:
        return NullTraceExporter()
    if not export.url:
        diagnostic("TRACE_EXPORT_ENABLED is set but TRACE_EXPORT_URL is empty; export disabled")
        return NullTraceExporter()
    return HttpTraceExporter(
        url=export.url,
        timeout=export.timeout,
        headers=dict(export.headers),
        policy=AttributePolicy(extra_allowed=frozenset(export.attribute_allowlist)),
        service=config.service_name,
        environment=config.environment,
    )


_lock = threading.Lock()
_runtime: Runtime | None = None
_atexit_registered = False


def get_runtime() -> Runtime:
    global _runtime
    runtime = _runtime
    if runtime is None:
        with _lock:
            if _runtime is None:
                _runtime = Runtime(LoggingConfig.from_env())
            runtime = _runtime
    return runtime


def install_runtime(runtime: Runtime) -> Runtime:
    global _runtime, _atexit_registered
    with _lock:
        previous = _runtime
        _runtime = runtime
        if not _atexit_registered:
            atexit.register(shutdown)
            _atexit_registered = True
    if previous is not None:
        previous.shutdown()
    return runtime


def shutdown() -> None:
    runtime = _runtime
    if runtime is not None:
        runtime.shutdown()


def reset_runtime() -> None:
    """Forget the configured runtime (tests)."""
    global _runtime
    with _lock:
        previous, _runtime = _runtime, None
    if previous is not None:
        previous.shutdown()
