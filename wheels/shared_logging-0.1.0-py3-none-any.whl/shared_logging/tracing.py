"""Trace context, spans and propagation.

The current span lives in a ``contextvars.ContextVar`` so it follows ``await``, tasks created with
``asyncio.create_task`` and ``asyncio.to_thread`` automatically, while concurrent requests each see
only their own span. Wire format for HTTP is W3C ``traceparent``.
"""

from __future__ import annotations

import contextvars
import re
import secrets
import threading
import time
from collections.abc import Iterator, Mapping, MutableMapping
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from types import MappingProxyType
from typing import Any

from . import _runtime

TRACEPARENT = "traceparent"
CORRELATION_HEADER = "x-correlation-id"
_TRACEPARENT_RE = re.compile(r"^([0-9a-f]{2})-([0-9a-f]{32})-([0-9a-f]{16})-([0-9a-f]{2})$")
_MAX_EVENTS = 100

STATUS_UNSET = "unset"
STATUS_OK = "ok"
STATUS_ERROR = "error"
STATUS_CANCELLED = "cancelled"


def new_trace_id() -> str:
    return secrets.token_hex(16)


def new_span_id() -> str:
    return secrets.token_hex(8)


def _iso(timestamp: float) -> str:
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat(timespec="milliseconds")


@dataclass(frozen=True, slots=True)
class TraceContext:
    """Identity of a span; this is what travels between services."""

    trace_id: str
    span_id: str
    parent_span_id: str | None = None
    sampled: bool = True
    correlation_id: str | None = None

    def to_traceparent(self) -> str:
        return f"00-{self.trace_id}-{self.span_id}-{'01' if self.sampled else '00'}"

    @classmethod
    def from_traceparent(
        cls, value: str | None, correlation_id: str | None = None
    ) -> TraceContext | None:
        """Parse a ``traceparent`` header; return ``None`` when absent or malformed."""
        match = _TRACEPARENT_RE.match((value or "").strip().lower())
        if not match:
            return None
        version, trace_id, span_id, flags = match.groups()
        if version == "ff" or set(trace_id) == {"0"} or set(span_id) == {"0"}:
            return None
        return cls(
            trace_id=trace_id,
            span_id=span_id,
            sampled=bool(int(flags, 16) & 1),
            correlation_id=correlation_id or None,
        )


class Span:
    """A unit of work inside one service. Create with :func:`span`, not directly."""

    def __init__(
        self,
        name: str,
        context: TraceContext,
        kind: str = "internal",
        attributes: Mapping[str, Any] | None = None,
    ) -> None:
        self.name = name
        self.context = context
        self.kind = kind
        self.attributes: dict[str, Any] = dict(attributes or {})
        self.events: list[dict[str, Any]] = []
        self.status = STATUS_UNSET
        self.status_description: str | None = None
        self._start_wall = time.time()
        self._start = time.perf_counter()
        self._duration_ms: float | None = None
        self._lock = threading.Lock()

    trace_id = property(lambda self: self.context.trace_id)
    span_id = property(lambda self: self.context.span_id)
    parent_span_id = property(lambda self: self.context.parent_span_id)

    @property
    def ended(self) -> bool:
        return self._duration_ms is not None

    def set_attribute(self, key: str, value: Any) -> None:
        self.attributes[key] = value

    def set_attributes(self, **attributes: Any) -> None:
        self.attributes.update(attributes)

    def set_status(self, status: str, description: str | None = None) -> None:
        self.status = status
        self.status_description = description

    def add_event(self, name: str, **attributes: Any) -> None:
        if len(self.events) >= _MAX_EVENTS:
            return
        self.events.append({"name": name, "timestamp": _iso(time.time()), "attributes": attributes})

    def record_exception(self, exc: BaseException) -> None:
        self.status = STATUS_ERROR
        self.status_description = f"{type(exc).__name__}: {exc}"
        self.attributes.setdefault("error.type", type(exc).__name__)
        self.add_event(
            "exception",
            **{"error.type": type(exc).__name__, "error.message": str(exc)},
        )

    def end(self) -> None:
        """Finish the span and hand it to the exporter pipeline (idempotent)."""
        with self._lock:
            if self._duration_ms is not None:
                return
            self._duration_ms = round((time.perf_counter() - self._start) * 1000, 3)
        if self.status == STATUS_UNSET:
            self.status = STATUS_OK
        runtime = _runtime.get_runtime()
        if self.context.sampled and runtime.processor is not None:
            config = runtime.config
            runtime.record_span(self.to_record(config.service_name, config.environment))

    def to_record(self, service: str, environment: str) -> dict[str, Any]:
        """Stable, serialisable representation of the span (the export schema)."""
        return {
            "trace_id": self.context.trace_id,
            "span_id": self.context.span_id,
            "parent_span_id": self.context.parent_span_id,
            "service": service,
            "environment": environment,
            "timestamp": _iso(self._start_wall),
            "duration_ms": self._duration_ms,
            "operation": self.name,
            "kind": self.kind,
            "status": self.status,
            "attributes": dict(self.attributes),
            "events": [dict(e) for e in self.events],
        }


_current: contextvars.ContextVar[Span | None] = contextvars.ContextVar(
    "shared_logging_span", default=None
)
_EMPTY: Mapping[str, Any] = MappingProxyType({})
_bound: contextvars.ContextVar[Mapping[str, Any]] = contextvars.ContextVar(
    "shared_logging_bound", default=_EMPTY
)


def current_span() -> Span | None:
    return _current.get()


def current_context() -> TraceContext | None:
    active = _current.get()
    return active.context if active else None


def current_trace_id() -> str | None:
    active = _current.get()
    return active.context.trace_id if active else None


def _child_context(parent: TraceContext | None) -> TraceContext:
    if parent is None:
        parent_span = _current.get()
        parent = parent_span.context if parent_span else None
    if parent is None:
        trace_id = new_trace_id()
        return TraceContext(trace_id, new_span_id(), None, True, trace_id)
    return TraceContext(
        trace_id=parent.trace_id,
        span_id=new_span_id(),
        parent_span_id=parent.span_id,
        sampled=parent.sampled,
        correlation_id=parent.correlation_id or parent.trace_id,
    )


def start_detached_span(
    name: str,
    *,
    kind: str = "internal",
    attributes: Mapping[str, Any] | None = None,
    parent: TraceContext | None = None,
) -> Span:
    """Create a span without making it current; the caller must call ``end()`` (client hooks)."""
    return Span(name, _child_context(parent), kind, attributes)


@contextmanager
def span(
    name: str,
    *,
    kind: str = "internal",
    attributes: Mapping[str, Any] | None = None,
    parent: TraceContext | None = None,
) -> Iterator[Span]:
    """Run a block as a (child) span.

    * inside another span: a child in the same trace;
    * with ``parent`` (a context received from another service): continues that trace;
    * otherwise: a new root trace.

    The previous context is restored on exit, so nothing leaks past the block.
    """
    new_span = start_detached_span(name, kind=kind, attributes=attributes, parent=parent)
    token = _current.set(new_span)
    try:
        yield new_span
    except GeneratorExit:
        raise
    except BaseException as exc:
        cancelled = isinstance(exc, KeyboardInterrupt | SystemExit)
        if cancelled or type(exc).__name__ == "CancelledError":
            new_span.set_status(STATUS_CANCELLED)
        else:
            new_span.record_exception(exc)
        raise
    finally:
        try:
            _current.reset(token)
        except ValueError:  # exited from a different Context (async-generator boundaries)
            _current.set(None)
        new_span.end()


def _lookup(carrier: Mapping[str, Any], key: str) -> str | None:
    if key in carrier:
        value = carrier[key]
    else:
        value = next((v for k, v in carrier.items() if str(k).lower() == key), None)
    if isinstance(value, bytes):
        value = value.decode("latin-1")
    return value if isinstance(value, str) else None


def extract_context(carrier: Mapping[str, Any] | None) -> TraceContext | None:
    """Read the incoming context from HTTP headers or message metadata (case-insensitive).

    Accepts ``traceparent`` or, for messages, the explicit ``trace_id`` + ``parent_span_id`` pair.
    """
    if not carrier:
        return None
    correlation = _lookup(carrier, CORRELATION_HEADER) or _lookup(carrier, "correlation_id")
    parsed = TraceContext.from_traceparent(_lookup(carrier, TRACEPARENT), correlation)
    if parsed is not None:
        return parsed
    trace_id = (_lookup(carrier, "trace_id") or "").lower()
    parent_id = (_lookup(carrier, "parent_span_id") or "").lower()
    if re.fullmatch(r"[0-9a-f]{32}", trace_id) and re.fullmatch(r"[0-9a-f]{16}", parent_id):
        return TraceContext(trace_id, parent_id, correlation_id=correlation or None)
    return None


@contextmanager
def continue_trace(
    carrier: Mapping[str, Any] | None,
    name: str,
    *,
    kind: str = "server",
    attributes: Mapping[str, Any] | None = None,
) -> Iterator[Span]:
    """Start the local span for an incoming request/message.

    Continues the trace found in ``carrier`` (the new span's parent is the remote span) or starts a
    new root trace when there is none.
    """
    with span(name, kind=kind, attributes=attributes, parent=extract_context(carrier)) as active:
        yield active


def inject_headers(headers: MutableMapping[str, str] | None = None) -> MutableMapping[str, str]:
    """Add ``traceparent`` (and ``x-correlation-id``) for the current span to outgoing headers."""
    target: MutableMapping[str, str] = headers if headers is not None else {}
    active = _current.get()
    if active is not None:
        target[TRACEPARENT] = active.context.to_traceparent()
        target[CORRELATION_HEADER] = active.context.correlation_id or active.context.trace_id
    return target


def inject_message_metadata(
    metadata: MutableMapping[str, Any] | None = None,
) -> MutableMapping[str, Any]:
    """Add trace fields to the metadata/headers of a queued message or event."""
    target: MutableMapping[str, Any] = metadata if metadata is not None else {}
    active = _current.get()
    if active is not None:
        ctx = active.context
        target[TRACEPARENT] = ctx.to_traceparent()
        target["trace_id"] = ctx.trace_id
        target["parent_span_id"] = ctx.span_id
        target["correlation_id"] = ctx.correlation_id or ctx.trace_id
    return target


continue_from_message = continue_trace  # same extraction rules; kept for readable call sites


@contextmanager
def bind(**fields: Any) -> Iterator[None]:
    """Attach extra fields to every log line emitted inside the block (any depth, any task)."""
    token = _bound.set({**_bound.get(), **fields})
    try:
        yield
    finally:
        try:
            _bound.reset(token)
        except ValueError:
            _bound.set(_EMPTY)


def bound_fields() -> Mapping[str, Any]:
    return _bound.get()
