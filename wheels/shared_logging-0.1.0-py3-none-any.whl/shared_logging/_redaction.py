"""Removal of secrets from anything that leaves the process (logs and exported traces)."""

from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

REDACTED = "[REDACTED]"

# "token" only matches the singular so counters such as ``max_tokens`` stay readable.
_SENSITIVE_KEY = re.compile(
    r"pass(word|wd|phrase)?|secret|token(?!s)|api[-_]?key|apikey|authorization|cookie|"
    r"credential|private[-_]?key|session[-_]?id|bearer",
    re.IGNORECASE,
)
_BEARER_VALUE = re.compile(r"(?i)\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]{6,}")
_MAX_DEPTH = 6


def is_sensitive_key(key: object) -> bool:
    return bool(_SENSITIVE_KEY.search(str(key)))


def redact_text(text: str) -> str:
    return _BEARER_VALUE.sub(lambda m: f"{m.group(1)} {REDACTED}", text)


def redact_value(key: object, value: Any, _depth: int = 0) -> Any:
    """Return ``value`` with secrets masked; ``key`` is the field name it is stored under."""
    if is_sensitive_key(key):
        return REDACTED
    if isinstance(value, str):
        return redact_text(value)
    if _depth >= _MAX_DEPTH:
        return value
    if isinstance(value, Mapping):
        return {str(k): redact_value(k, v, _depth + 1) for k, v in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [redact_value(key, item, _depth + 1) for item in value]
    return value
